# Proyecto Spotify - Programación II
Estructura lista para GitHub.
